import React, { Component } from "react";
import Card from "./Card";

class Movies extends Component {
  render() {
    const { movies } = this.props;
    return (
      <div className="movies">
        {movies.map((movie) => (
          <Card key={movie.imdbID} {...movie} />
        ))}
      </div>
    );
  }
}

export default Movies;

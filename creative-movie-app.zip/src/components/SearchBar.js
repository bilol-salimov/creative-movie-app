import React, { Component } from "react";

class SearchBar extends Component {
  state = {
    search: "",
  };

  handleText = (e) => {
    this.setState({
      search: e.target.value,
    });
  };

  enterSearchText = (e) => {
    if (e.key === "Enter") this.props.searchBar(this.state.search);
  };

  render() {
    const { search } = this.state;
    return (
      <div className="search-wrapper">
        <form action="javascript:" className="search-bar">
          <input
            type="search"
            name="search"
            pattern=".*\S.*"
            autoComplete="off"
            onChange={this.handleText}
            onKeyUp={this.enterSearchText}
            value={search}
            required
          />
          <button className="search-btn" type="submit">
            <span>Search</span>
          </button>
        </form>
      </div>
    );
  }
}

export default SearchBar;
